package com.asset.ccat.gateway;
class MainApplicationTests {

    //@Test
    void contextLoads() {
    }

}
