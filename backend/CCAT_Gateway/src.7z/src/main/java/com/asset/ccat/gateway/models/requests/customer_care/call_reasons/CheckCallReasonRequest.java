package com.asset.ccat.gateway.models.requests.customer_care.call_reasons;

import com.asset.ccat.gateway.models.requests.BaseRequest;

public class CheckCallReasonRequest extends BaseRequest {
}
