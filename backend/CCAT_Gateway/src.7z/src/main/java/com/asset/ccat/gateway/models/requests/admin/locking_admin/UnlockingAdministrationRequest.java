package com.asset.ccat.gateway.models.requests.admin.locking_admin;

import com.asset.ccat.gateway.models.requests.SubscriberRequest;

/**
 * @author wael.mohamed
 */
public class UnlockingAdministrationRequest extends SubscriberRequest {

}
