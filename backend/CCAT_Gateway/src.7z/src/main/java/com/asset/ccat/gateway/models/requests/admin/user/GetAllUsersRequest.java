package com.asset.ccat.gateway.models.requests.admin.user;

import com.asset.ccat.gateway.models.requests.BaseRequest;

import java.io.Serializable;

/**
 * @author nour.ihab
 */
public class GetAllUsersRequest extends BaseRequest implements Serializable {

}
