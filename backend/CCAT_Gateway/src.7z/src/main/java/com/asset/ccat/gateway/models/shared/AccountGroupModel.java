package com.asset.ccat.gateway.models.shared;

/**
 *
 * @author marwa.elshawarby
 */
public class AccountGroupModel {

    private Integer groupId;
    private String name;

    public Integer getGroupId() {
        return groupId;
    }

    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
