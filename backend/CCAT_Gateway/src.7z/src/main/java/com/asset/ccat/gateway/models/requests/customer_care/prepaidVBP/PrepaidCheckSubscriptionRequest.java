package com.asset.ccat.gateway.models.requests.customer_care.prepaidVBP;

import com.asset.ccat.gateway.models.requests.SubscriberRequest;

public class PrepaidCheckSubscriptionRequest extends SubscriberRequest {
    public PrepaidCheckSubscriptionRequest() {
    }

    @Override
    public String toString() {
        return "PrepaidCheckSubscriptionRequest{}";
    }
}
