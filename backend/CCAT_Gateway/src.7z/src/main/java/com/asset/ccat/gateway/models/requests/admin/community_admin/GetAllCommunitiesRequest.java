package com.asset.ccat.gateway.models.requests.admin.community_admin;


import com.asset.ccat.gateway.models.requests.BaseRequest;

public class GetAllCommunitiesRequest extends BaseRequest {
}
