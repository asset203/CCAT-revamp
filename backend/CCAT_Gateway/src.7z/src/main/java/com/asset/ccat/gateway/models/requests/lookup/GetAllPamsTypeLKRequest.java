package com.asset.ccat.gateway.models.requests.lookup;

import com.asset.ccat.gateway.models.requests.BaseRequest;

/**
 * @author nour.ihab
 */
public class GetAllPamsTypeLKRequest extends BaseRequest {

}
