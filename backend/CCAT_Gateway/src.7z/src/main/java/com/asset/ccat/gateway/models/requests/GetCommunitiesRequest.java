package com.asset.ccat.gateway.models.requests;

public class GetCommunitiesRequest extends SubscriberRequest{

}
