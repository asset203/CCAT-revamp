package com.asset.ccat.gateway.models.requests.customer_care.voucher_refill;

import com.asset.ccat.gateway.models.requests.BaseRequest;

/**
 * @author nour.ihab
 */
public class GetAllPaymentsProfilesRequest extends BaseRequest {

}
