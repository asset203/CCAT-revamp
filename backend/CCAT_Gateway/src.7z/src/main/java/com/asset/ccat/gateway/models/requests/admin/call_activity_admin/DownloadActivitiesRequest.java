package com.asset.ccat.gateway.models.requests.admin.call_activity_admin;

import com.asset.ccat.gateway.models.requests.BaseRequest;


public class DownloadActivitiesRequest extends BaseRequest {
}
