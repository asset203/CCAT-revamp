package com.asset.ccat.gateway.models.requests.admin.air_servers;

import com.asset.ccat.gateway.models.requests.BaseRequest;
/**
 * @author Assem.Hassan
 */
public class GetAllAirServersRequest extends BaseRequest {

}
