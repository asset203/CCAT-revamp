/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.asset.ccat.gateway.models.requests.customer_care.history;

import com.asset.ccat.gateway.models.requests.SubscriberRequest;

/**
 *
 * @author wael.mohamed
 */
public class GetSubscriberActivityDetailsRequest extends SubscriberRequest {

}
