package com.asset.ccat.gateway.models.requests.admin.business_plan;

import com.asset.ccat.gateway.models.requests.BaseRequest;

/**
 *
 * @author nour.ihab
 */
public class GetAllBusinessPlansRequest extends BaseRequest {

}
