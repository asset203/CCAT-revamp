package com.asset.ccat.gateway.models.requests.lookup;

import com.asset.ccat.gateway.models.requests.BaseRequest;

/**
 * @author mohamed.metwaly
 */
public class GetAllFafIndicatorsRequest extends BaseRequest {
}
