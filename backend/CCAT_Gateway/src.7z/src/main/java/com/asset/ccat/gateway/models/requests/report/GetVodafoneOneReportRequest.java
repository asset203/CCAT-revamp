package com.asset.ccat.gateway.models.requests.report;

/**
 * @author mohamed.metwaly
 */
public class GetVodafoneOneReportRequest extends GetDssReportRequest{
}
