package com.asset.ccat.gateway.models.requests.admin.service_offering_plans;

import com.asset.ccat.gateway.models.requests.BaseRequest;

public class GetAllServiceOfferingPlansRequest extends BaseRequest {

}
