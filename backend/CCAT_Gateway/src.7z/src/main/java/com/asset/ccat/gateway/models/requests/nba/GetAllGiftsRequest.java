package com.asset.ccat.gateway.models.requests.nba;

import com.asset.ccat.gateway.models.requests.SubscriberRequest;

public class GetAllGiftsRequest extends SubscriberRequest {
}
