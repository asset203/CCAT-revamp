package com.asset.ccat.gateway.models.requests.admin.dynamic_page;

import com.asset.ccat.gateway.models.requests.BaseRequest;

public class GetAllDynamicPagesRequest extends BaseRequest{

}
