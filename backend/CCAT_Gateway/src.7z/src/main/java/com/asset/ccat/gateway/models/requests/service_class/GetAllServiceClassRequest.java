package com.asset.ccat.gateway.models.requests.service_class;

import com.asset.ccat.gateway.models.requests.BaseRequest;

/**
 * @author wael.mohamed
 */
public class GetAllServiceClassRequest extends BaseRequest {

}
