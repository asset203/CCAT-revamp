package com.asset.ccat.gateway.models.requests.admin.account_groups;

import com.asset.ccat.gateway.models.requests.BaseRequest;

/**
 * @author mohamed.metwaly
 */
public class GetAllAccountGroupsRequest extends BaseRequest {


}
