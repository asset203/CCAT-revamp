package com.asset.ccat.gateway.models.requests.admin.account_groups_bits_desc;

import com.asset.ccat.gateway.models.requests.BaseRequest;

public class GetAllAccountGroupsBitsDescRequest extends BaseRequest {
}
