package com.asset.ccat.gateway.models.requests.admin.profile_features;

import com.asset.ccat.gateway.models.requests.BaseRequest;

/**
 * @author mohamed.metwaly
 */
public class GetProfilesFeaturesRequest extends BaseRequest {
    @Override
    public String toString() {
        return "GetProfilesFeaturesRequest{}";
    }
}
