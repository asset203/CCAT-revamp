package com.asset.ccat.gateway.models.requests.customer_care.language;

import com.asset.ccat.gateway.models.requests.BaseRequest;

/**
 * @author wael.mohamed
 */
public class GetAllLanguageRequest extends BaseRequest {

}
