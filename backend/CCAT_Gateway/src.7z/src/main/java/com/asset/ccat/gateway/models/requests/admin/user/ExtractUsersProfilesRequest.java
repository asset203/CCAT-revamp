package com.asset.ccat.gateway.models.requests.admin.user;

import com.asset.ccat.gateway.models.requests.BaseRequest;

public class ExtractUsersProfilesRequest extends BaseRequest {
    public ExtractUsersProfilesRequest() {
    }
}
