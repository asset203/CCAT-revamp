package com.asset.ccat.gateway.models.requests.admin.flex_share_history;

import com.asset.ccat.gateway.models.requests.BaseRequest;

/**
 * @author Assem.Hassan
 */
public class GetAllFlexShareHistoryNodesRequest extends BaseRequest {

}
