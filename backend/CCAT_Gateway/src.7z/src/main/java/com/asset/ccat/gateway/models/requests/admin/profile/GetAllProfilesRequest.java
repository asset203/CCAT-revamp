package com.asset.ccat.gateway.models.requests.admin.profile;

import com.asset.ccat.gateway.models.requests.BaseRequest;

/**
 * @author nour.ihab
 */
public class GetAllProfilesRequest extends BaseRequest {

}
