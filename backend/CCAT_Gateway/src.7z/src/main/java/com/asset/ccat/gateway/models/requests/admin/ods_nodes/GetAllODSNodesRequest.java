package com.asset.ccat.gateway.models.requests.admin.ods_nodes;


import com.asset.ccat.gateway.models.requests.BaseRequest;

/**
 * @author Assem.Hassan
 */
public class GetAllODSNodesRequest extends BaseRequest {

}
