package com.asset.ccat.gateway.models.requests.admin.dss_nodes;

import com.asset.ccat.gateway.models.requests.BaseRequest;

/**
 * @author Assem.Hassan
 */
public class GetAllDSSNodesRequest extends BaseRequest {

}
