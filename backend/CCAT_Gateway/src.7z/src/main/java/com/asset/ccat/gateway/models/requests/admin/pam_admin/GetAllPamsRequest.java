package com.asset.ccat.gateway.models.requests.admin.pam_admin;

import com.asset.ccat.gateway.models.requests.BaseRequest;

/**
 * @author nour.ihab
 */
public class GetAllPamsRequest extends BaseRequest {

}
