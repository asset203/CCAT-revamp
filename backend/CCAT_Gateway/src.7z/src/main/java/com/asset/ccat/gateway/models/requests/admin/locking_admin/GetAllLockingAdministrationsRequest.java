package com.asset.ccat.gateway.models.requests.admin.locking_admin;

import com.asset.ccat.gateway.models.requests.SubscriberRequest;

/**
 * @author nour.ihab
 */
public class GetAllLockingAdministrationsRequest extends SubscriberRequest {

}
