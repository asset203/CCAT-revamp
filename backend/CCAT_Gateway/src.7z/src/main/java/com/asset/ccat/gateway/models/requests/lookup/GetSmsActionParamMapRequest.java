package com.asset.ccat.gateway.models.requests.lookup;

import com.asset.ccat.gateway.models.requests.BaseRequest;

public class GetSmsActionParamMapRequest extends BaseRequest {
}
