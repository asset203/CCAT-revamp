package com.asset.ccat.gateway.models.requests.lookup;

import com.asset.ccat.gateway.models.requests.BaseRequest;

/**
 *
 * @author marwa.elshawarby
 */
public class GetFeaturesLKRequest extends BaseRequest{
    
}
