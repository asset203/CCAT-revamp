package com.asset.ccat.gateway.models.requests.admin.service_offering_description;

import com.asset.ccat.gateway.models.requests.BaseRequest;

public class GetAllServiceOfferingDescriptionRequest extends BaseRequest {
}
