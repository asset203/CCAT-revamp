package com.asset.ccat.gateway.models.requests.admin.sms_template_cs;

import com.asset.ccat.gateway.models.requests.BaseRequest;

public class GetAllTemplatesRequest extends BaseRequest {

}
