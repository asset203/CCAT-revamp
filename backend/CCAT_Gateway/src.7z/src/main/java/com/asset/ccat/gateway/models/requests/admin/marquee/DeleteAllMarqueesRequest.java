package com.asset.ccat.gateway.models.requests.admin.marquee;

import com.asset.ccat.gateway.models.requests.BaseRequest;

/**
 * @author nour.ihab
 */
public class DeleteAllMarqueesRequest extends BaseRequest {

}
