package com.asset.ccat.gateway.models.requests.admin.admin_faf_plan;

import com.asset.ccat.gateway.models.requests.BaseRequest;

/**
 * @author mohamed.metwaly
 */
public class GetAllAdminFafPlansRequest extends BaseRequest {
   
}
